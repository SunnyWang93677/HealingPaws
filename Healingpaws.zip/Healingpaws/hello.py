#if __name__ == "__main__":
#from Healingpaws.healingpawsapp import app

print("hello word")
from healingpawsapp import *
app.run(host="0.0.0.0",port="1315",debug=True)
