from healingpawsapp.models import *

def test_create():
    db.create_all()

def test_get_allusers():
    return None